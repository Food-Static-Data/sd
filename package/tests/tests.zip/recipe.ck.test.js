/* global describe, it, expect */
'use strict'
const { recipeCk } = require('@files')

describe('recipeCk data files returns array', () => {
  it('these tests prevent any issues and problems, also to break the structure of recipeCk', () => {
    expect(recipeCk).not.toBe('')
  })
})
